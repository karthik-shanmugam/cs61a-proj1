test = {
  'names': [
    'q10',
    '10'
  ],
  'note': """
  Tests for Q10 are not included with ok.
  Submit your project to receive results by email.
  """,
  'points': 3
}