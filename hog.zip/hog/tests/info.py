info = {
  'hash_key': 'g1yuy1ouxy4liaxfvbbz37t3xahjzkf9c3thjciao9xpq746rtiyugipq95w7d6qllkwzjw2cr27ytbjc8s3zcc6fnpez20oj9f2zlp1egxid5sok0xjtjwqyvoxopcy',
  'name': 'proj1',
  'params': {
    'doctest': {
      'cache': """
      import hog
      from hog import *
      """
    }
  },
  'src_files': [
    'hog.py'
  ],
  'version': '1.0'
}