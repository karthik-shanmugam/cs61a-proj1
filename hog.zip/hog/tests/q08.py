test = {
  'names': [
    'q08',
    'q8',
    '8'
  ],
  'points': 1,
  'suites': [
    [
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(0, 0)
        674201a6cd91521b7e90469728afef52
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(70, 50)
        674201a6cd91521b7e90469728afef52
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(50, 70)
        625a374dc1f9b8422bddcfd42bc6571c
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(32, 4, 5, 4)
        625a374dc1f9b8422bddcfd42bc6571c
        # locked
        """,
        'type': 'doctest'
      },
      {
        'locked': True,
        'test': """
        >>> bacon_strategy(20, 25, 5, 4)
        a4e96e54b9b170437d66dd7bd7e6c37c
        # locked
        """,
        'type': 'doctest'
      }
    ]
  ]
}